require.config({
    baseUrl: '/js',
    paths: {
        'mui': './libs/mui.min',
        'index': 'index'
    }
})